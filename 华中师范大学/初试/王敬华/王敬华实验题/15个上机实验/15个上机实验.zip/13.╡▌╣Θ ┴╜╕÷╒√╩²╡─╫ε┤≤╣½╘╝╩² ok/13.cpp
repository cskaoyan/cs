#include <stdio.h>
Greatestcommondenominaton(int,int);

void main()
{
	int num1,num2,p;
	printf("please input the first number:\n");
		scanf("%d",&num1);
    printf("please input the second number:\n");
		scanf("%d",&num2);
		if(num1>0&&num2>0)
		{
			p=Greatestcommondenominaton(num1,num2);
			printf("Greatest common denominaton is %d\n",p);
		}
		else
			printf("error!please check it ");
}
Greatestcommondenominaton(int num1 ,int num2)
{
	int m,n;
	if(num1==num2)
		return(num1);

	if(num1>num2)
	{
		m=num1-num2;
		n=Greatestcommondenominaton(m,num2);
		return(n);
	}

	if(num2>num1)
	{
		m=num2-num1;
		n=Greatestcommondenominaton(m,num1);
		return(n);
	}



}