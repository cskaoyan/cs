#include <stdio.h>

void main()
{
	int A[100] ,B[2][100];
	int i,j,num;

//
	printf("�����������ڵ�Ԫ��,����0��β:\n");
	for(i = 0,num=0;i<100;i++)
	{
		scanf("%d",&A[i]);
		num++;
		if (A[i]==0)
			break;
	}

//	
	for(i=0;i<num-1;i++)
	{
		B[0][i] = A[i];
     	B[1][i]=1;
	}
//
	for(i = 0;i<num-1;i++)
	{
		for(j=0;j<num-1;j++)
		{
			if(B[0][i]>B[0][j])
				B[1][i]=B[1][i]+1;
			
		}
	}
	for(i=0;i<num-1;i++)
	printf("%d  ",B[1][i]);
}

